from django.apps import AppConfig


class MapLogConfig(AppConfig):
    name = 'map_log'
